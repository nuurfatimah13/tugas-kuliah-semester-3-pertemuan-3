<?php

# membuat variable
$nama = "Fathimah";
$jurusan = "Teknik Informatika";

# mengakses variable
echo "$nama <br>";
echo $jurusan;