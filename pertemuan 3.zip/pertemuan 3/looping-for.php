<?php

# looping for
for ($i = 0; $i < 10; $i++) {
  echo "Looping ke $i <br>";
}
