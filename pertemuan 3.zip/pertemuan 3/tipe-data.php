<?php

# string
$nama = "Fathimah";

# integer
$umur = 19;

# float
$ipk = 3.90;

# boolean
$isMarried = false;
