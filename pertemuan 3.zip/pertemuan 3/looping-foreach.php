<?php

# array
$animals = ['Ayam', 'Ikan', 'Kucing'];

# looping foreach
foreach ($animals as $animal) {
  echo "$animal <br>";
}
